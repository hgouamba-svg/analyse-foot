// Proxy CORS optionnel pour Statline — à déployer sur Cloudflare Workers si les
// appels directs depuis le navigateur sont bloqués, ou pour ne plus exposer
// la clé API côté client.
//
// Configuration : ajoute une variable d'environnement "API_KEY" dans les
// réglages du Worker (Settings > Variables), contenant ta clé API-Football.
//
// Une fois déployé, remplace API_BASE dans app.html par l'URL de ce Worker,
// et retire la clé API du localStorage côté client (elle n'est plus nécessaire).

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
      });
    }

    const targetUrl = "https://v3.football.api-sports.io" + url.pathname + url.search;

    const apiResponse = await fetch(targetUrl, {
      headers: { "x-apisports-key": env.API_KEY },
    });

    const body = await apiResponse.text();

    return new Response(body, {
      status: apiResponse.status,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    });
  },
};
